<?php

/**
 * Instagram PHP API
 *
 * @link https://github.com/cosenary/Instagram-PHP-API
 * @author Christian Metz
 * @since 01.10.2013
 */

require '../src/Instagram.php';
use MetzWeb\Instagram\Instagram;

// initialize class
$instagram = new Instagram(array(
  'apiKey'      => '3f16803248ed475dbe12692140ddc2d7',
  'apiSecret'   => '517b4842351347b3bd63532eeaf78f34',
  'apiCallback' => 'https://lojavirtual.digital/temp1/Instagram-PHP-API/example/success.php' // must point to success.php
));

// receive OAuth code parameter
$code = $_GET['code'];

// check whether the user has granted access
if (isset($code)) {

  // receive OAuth token object
  $data = $instagram->getOAuthToken($code);
  $username = $data->user->username;

  // store user access token
  $instagram->setAccessToken($data);

  // now you have access to all authenticated user methods
  $result = $instagram->getUserMedia();

} else {

  // check whether an error occurred
  if (isset($_GET['error'])) {
    echo 'An error occurred: ' . $_GET['error_description'];
  }

}

?>

        <?php
          // display all user likes
          foreach ($result->data as $media) {
		?>
<div id="divdrag14307179362878" style="background-color: #FFFFFF; width: 50px; float: left; overflow: hidden; height: 50px;
                background: rgba(255,255,255,0.8);
                position: relative;
                display: inline-block;
                margin: 5px;
                vertical-align: top;
                border: 1px solid #acacac;
                padding: 6px 6px 6px 6px;
                -webkit-box-shadow: 1px 1px 4px rgba(0,0,0,0.16);
                box-shadow: 1px 1px 4px rgba(0,0,0,0.16);
                font-size: 14px;
                ">
	<?
            // output media
            if ($media->type === 'video') {
            } else {
              // image
              $image = $media->images->low_resolution->url;
              $content = "<img class=\"media\" src=\"{$image}\" id=\"drag14307179362878\" draggable=\"true\" ondragstart=\"drag(event)\" style=\"max-width:100%; max-height:100%;\" />";
            }
            // output media
            echo $content . "</div>";
          }
        ?>
