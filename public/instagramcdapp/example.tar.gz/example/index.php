<?php

require '../src/Instagram.php';
use MetzWeb\Instagram\Instagram;

// initialize class
$instagram = new Instagram(array(
  'apiKey'      => '3f16803248ed475dbe12692140ddc2d7',
  'apiSecret'   => '517b4842351347b3bd63532eeaf78f34',
  'apiCallback' => 'https://lojavirtual.digital/temp1/Instagram-PHP-API/example/success.php' // must point to success.php
));

// create login URL
$loginUrl = $instagram->getLoginUrl();

?>
            <a class="button" target="_blank" href="<?php echo $loginUrl ?>">Entrar com Instagram</a>
