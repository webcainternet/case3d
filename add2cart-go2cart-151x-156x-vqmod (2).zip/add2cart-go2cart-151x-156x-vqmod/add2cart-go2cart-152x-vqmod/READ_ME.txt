*****************************************************
*     Mod: Add 2 Cart Go 2 Cart - 152x - vQmod      *
* Version: 1.0                                      *
*  Author: Best-Byte - www.best-byte.com            *
* Contact: support@best-byte.com                    *
*    Date: March 2012                               *
*****************************************************

REQUIREMENTS:
=============
Opencart Versions 1.5.2.x

vQmod Versions 2.1.x (optional)

vQmod not required if you manually add code to javascript and product.tpl file.

WHAT DOES IT DO:
================
This mod takes you to the shopping cart when you add a product to the cart.

FEATURE OVERVIEW:
=================
* Adds the product to the cart and redirects you to the shopping cart getting customers 1 step closer to a sale.
* Uses vQmod for quick and easy installation with no file modifications.
* If not using vQmod just need to add 1 line of code to javascript and product.tpl file.
* Detailed instructions included in download.
* Free installation and support.

COMPATIBILITY:
==============
Successfully tested on OpenCart Versions 1.5.2.x with Default Theme and vQmod Versions 2.1.x.

vQmod not required if you manually add code to javascript and product.tpl file.

LICENSE:
========
This is a free mod made by Best-Byte and can only be used for personal use. 
You can modify it as you like as long as all references to Best-Byte are left intact. 
You can not sell this mod but you can give it away for free as long as the archive and all references to Best-Byte are left intact.

INSTALLATION:
=============
1) ALWAYS make a backup of your site before applying new mods etc. Better to be safe than sorry.

2) Upload the contents of the folder called upload (which are the folders called catalog and vqmod) to
   the root directory of your OpenCart installation. These are new files and no files should be overwritten.
   
3) If you don't have vQmod or don't want to use it or already have edits in your common.js file then you will 
   need to edit your common.js file located in the catalog/view/javascript folder. 

Look for the following at around line 104 under the function addToCart:

			if (json['success']) {
				$('#notification').html('<div class="success" style="display: none;">' + json['success'] + '<img src="catalog/view/theme/default/image/close.png" alt="" class="close" /></div>');
				
				$('.success').fadeIn('slow');
				
				$('#cart-total').html(json['total']);
				
				$('html, body').animate({ scrollTop: 0 }, 'slow');
			}	
		}
	});
}

Add the 1 line of code to it where it says Added by Best-Byte like the example below:
         
			if (json['success']) {
				$('#notification').html('<div class="success" style="display: none;">' + json['success'] + '<img src="catalog/view/theme/default/image/close.png" alt="" class="close" /></div>');
				
				$('.success').fadeIn('slow');
				
				$('#cart-total').html(json['total']);
				
				$('html, body').animate({ scrollTop: 0 }, 'slow');
        
        window.location.href = 'index.php?route=checkout/cart';  // Added by Best-Byte // 
			}	
		}
	});
}

4) You will also need to edit the product.tpl file located in the catalog/view/theme/default/template/product folder.

Look for the following at around line 354 under the function #button-cart:

			if (json['success']) {
				$('#notification').html('<div class="success" style="display: none;">' + json['success'] + '<img src="catalog/view/theme/default/image/close.png" alt="" class="close" /></div>');
					
				$('.success').fadeIn('slow');
					
				$('#cart-total').html(json['total']);
				
				$('html, body').animate({ scrollTop: 0 }, 'slow'); 
			}	
		}
	});
});

Add the 1 line of code to it where it says Added by Best-Byte like the example below:

			if (json['success']) {
				$('#notification').html('<div class="success" style="display: none;">' + json['success'] + '<img src="catalog/view/theme/default/image/close.png" alt="" class="close" /></div>');
					
				$('.success').fadeIn('slow');
					
				$('#cart-total').html(json['total']);
				
				$('html, body').animate({ scrollTop: 0 }, 'slow'); 
        
        window.location.href = 'index.php?route=checkout/cart';  // Added by Best-Byte //          
			}	
		}
	});
});

5) This will apply the add2cart go2cart to all the add to cart buttons in your shop.

6) That is all. Thank you for downloading and using this mod. If you like this mod please provide a star rating for it.
   
        